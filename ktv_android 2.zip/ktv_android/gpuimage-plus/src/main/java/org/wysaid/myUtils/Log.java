package org.wysaid.myUtils;

/**
 * Created by miku on 15-12-1.
 */
public class Log {
    public static void e(String tag,String text){
        log(tag,text);
    }

    public static void d(String tag,String text){
        log(tag,text);
    }

    public static void i(String tag,String text){
        log(tag,text);
    }

    public static void w(String tag,String text){
        log(tag,text);
    }

    private static void log(String tag,String text){
        if(Common.DEBUG){
            android.util.Log.e(tag,text);
        }
    }
}
