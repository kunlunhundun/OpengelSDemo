package org.wysaid.view;

/**
 * Created by wangyang on 15/7/27.
 */


import android.content.Context;

import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.View;

import org.wysaid.camera.CameraManager;
import org.wysaid.myUtils.Common;

import org.wysaid.myUtils.Log;
import org.wysaid.myUtils.Viewport;
import org.wysaid.nativePort.CGEFrameRecorder;

import java.nio.ByteBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;


public class CameraGLSurfaceView extends GLSurfaceView implements GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener{

    private String LOG_TAG = Common.LOG_TAG;

    private static final int STOPPED = 0;
    private static final int STARTED = 1;

    public static final int CAMERA_OPEN_FAILED = -1;
    public static final int CAMERA_OPENED = -2;

    public class ClearColor {
        public float r, g, b, a;
    }

    public interface CaptureCallback {

        void captureCallback(byte[] rgbaData);
    }

    private ClearColor clearColor;


    private boolean mEnabled=false;
    private boolean mSurfaceExist=false;
    private int mState = STOPPED;
    private Object mSyncObject = new Object();


    private int mRecordWidth = 480;
    private int mRecordHeight = 640;
    public int maxTextureSize = 0;
    private SurfaceTexture mSurfaceTexture;
    private int mTextureID;
    private CGEFrameRecorder mFrameRecorder;
    private Viewport mDrawViewport = new Viewport();


    public int viewWidth;
    public int viewHeight;

    //是否使用后置摄像头
    private volatile boolean mIsCameraBackForward = false;

    private String mCameraFilterConfig=null;


    private float mMaskAspectRatio = 1.0f;
    private float[] mTransformMatrix = new float[16];

    private boolean mIsUsingMask = false;
    private boolean mFitFullView = false;

    private CaptureCallback mCaptureCallback;
    private final int[] mCaptureLock = new int[0];
    private int mCaptureWidth, mCaptureHeight;
    private ByteBuffer mCaptureBuffer;
    private int crop_x,crop_y;

    private CameraManager mCameraManager;
    private OpenCameraListener mCameraListener;

    public CameraGLSurfaceView(Context context) {
        this(context, null);
    }

    public CameraGLSurfaceView(Context context, AttributeSet attrs) {
        super(context, attrs);
        LOG_TAG=LOG_TAG+mDrawViewport.toString();
        Log.i(LOG_TAG, "CameraGLSurfaceView2 Construct...");
        setEGLContextClientVersion(2);
        setEGLConfigChooser(8, 8, 8, 8, 8, 0);
        getHolder().setFormat(PixelFormat.RGBA_8888);
        setRenderer(this);
        setRenderMode(RENDERMODE_WHEN_DIRTY);
        clearColor = new ClearColor();
    }

    public void enableView(){
        Log.e(LOG_TAG, "enableView 0");
        queueEvent(new Runnable() {
            @Override
            public void run() {
                synchronized (mSyncObject){
                    mEnabled=true;
                    checkCurrentState();
                }
            }
        });
    }

    public void disableView(){
        Log.e(LOG_TAG, "disableView 0");
        queueEvent(new Runnable() {
            @Override
            public void run() {
                Log.e(LOG_TAG, "disableView 1");
                synchronized (mSyncObject) {
                    mEnabled = false;
                    checkCurrentState();
                }
            }
        });

    }

    public void setOpenCaremaListener(OpenCameraListener listener) {
        this.mCameraListener = listener;
    }

    @Override
    public void onFrameAvailable(SurfaceTexture surfaceTexture) {
        requestRender();
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        Log.i(LOG_TAG, "onSurfaceCreated");
//        if(mCameraManager==null){
//            mCameraManager=new CameraManager();
//        }
//
//        if(!mCameraManager.isCameraOpened()) {
//
//            int facing = mIsCameraBackForward ? Camera.CameraInfo.CAMERA_FACING_BACK : Camera.CameraInfo.CAMERA_FACING_FRONT;
//
//            if(!mCameraManager.tryOpenCamera(null, facing)) {
//                Log.e(LOG_TAG, "相机启动失败!!");
//            }
//        }
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        Log.i(LOG_TAG, "onSurfaceChanged");

        GLES20.glClearColor(clearColor.r, clearColor.g, clearColor.b, clearColor.a);

        viewWidth = width;
        viewHeight = height;

        calcViewport();

        synchronized(mSyncObject) {
            if (!mSurfaceExist) {
                Log.i(LOG_TAG, "surfaceChanged 1");
                createSurfaceTexture();
                mSurfaceExist = true;
                checkCurrentState();
            } else {
                /** Surface changed. We need to stop camera and restart with new parameters */
	                /* Pretend that old surface has been destroyed */
                Log.i(LOG_TAG, "surfaceChanged 2");
                destroySurfaceTexture();
                mSurfaceExist = false;
                checkCurrentState();
	                /* Now use new surface. Say we have it now */
                Log.i(LOG_TAG, "surfaceChanged 3");
                createSurfaceTexture();
                mSurfaceExist = true;
                checkCurrentState();
            }
        }

    }



    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Log.i(LOG_TAG,"surfaceCreated");
        super.surfaceCreated(holder);
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        Log.i(LOG_TAG,"surfaceChanged");
        super.surfaceChanged(holder, format, w, h);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        Log.i(LOG_TAG,"surfaceDestroyed");
        super.surfaceDestroyed(holder);
        synchronized(mSyncObject) {
            mSurfaceExist = false;
            checkCurrentState();
            if(mCameraManager!=null){
                mCameraManager.stopCamera();
                mCameraManager=null;
            }
            destroySurfaceTexture();
        }
    }

    private long mTimeCount = 0;
    private long mFramesCount = 0;
    private long mLastTimestamp = 0;
    @Override
    public void onDrawFrame(GL10 gl) {
        if(mSurfaceTexture == null || mCameraManager==null || !mCameraManager.isPreviewing()) {
            //防止双缓冲情况下最后几帧抖动
            if(mFrameRecorder != null) {
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
                mFrameRecorder.render(mDrawViewport.x, mDrawViewport.y, mDrawViewport.width, mDrawViewport.height);
            }

            return;
        }

        mSurfaceTexture.updateTexImage();

        mSurfaceTexture.getTransformMatrix(mTransformMatrix);
        mFrameRecorder.update(mTextureID, mTransformMatrix);

        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);

        if(mCaptureCallback != null) {

            synchronized (mCaptureLock) {

                // double judgement for mCaptureCallback ensure both performance and safety
                if(mCaptureCallback != null) {

                    GLES20.glViewport(0, 0, mRecordWidth, mRecordHeight);

                    mFrameRecorder.drawCache();

                    mCaptureBuffer.position(0);
                    GLES20.glReadPixels(crop_x, crop_y, mCaptureWidth, mCaptureHeight, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, mCaptureBuffer);

                    if(mCaptureCallback != null) {
                        mCaptureCallback.captureCallback(mCaptureBuffer.array());
                    }
                }
            }
        }

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);

        GLES20.glEnable(GLES20.GL_BLEND);
        mFrameRecorder.render(mDrawViewport.x, mDrawViewport.y, mDrawViewport.width, mDrawViewport.height);
        GLES20.glDisable(GLES20.GL_BLEND);

        if(mLastTimestamp == 0)
            mLastTimestamp = System.currentTimeMillis();

        long currentTimestamp = System.currentTimeMillis();

        ++mFramesCount;
        mTimeCount += currentTimestamp - mLastTimestamp;
        mLastTimestamp = currentTimestamp;
        if(mTimeCount >= 1000) {
            Log.i(LOG_TAG, String.format("每秒重绘帧率: %d", mFramesCount));
            mTimeCount %= 1000;
            mFramesCount = 0;
        }
    }


    private void createSurfaceTexture() {
        Log.i(LOG_TAG, "createSurfaceTexture");

        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glDisable(GLES20.GL_STENCIL_TEST);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);

        int texSize[] = new int[1];

        GLES20.glGetIntegerv(GLES20.GL_MAX_TEXTURE_SIZE, texSize, 0);
        maxTextureSize = texSize[0];

        mTextureID = Common.genSurfaceTextureID();
        mSurfaceTexture = new SurfaceTexture(mTextureID);
        mSurfaceTexture.setOnFrameAvailableListener(this);

        mFrameRecorder = new CGEFrameRecorder();
        if(!mFrameRecorder.init(mRecordWidth, mRecordHeight, mRecordWidth, mRecordHeight)) {
            Log.e(LOG_TAG, "Frame Recorder init failed!");
        }

//        com.rcsing.manager.ActivityManager.getInstance().;
//        if (getContext() instanceof  Activity) {
//            int rotation = ((Activity)getContext()).getWindowManager ().getDefaultDisplay().getRotation();
//            android.util.Log.e("CSLSV", "rotation:" + rotation);
//        }

        setSrcRotation();
//        android.util.Log.e("CM", "createSurfaceTexture times:" + times); // * times

        mFrameRecorder.setSrcFlipScale(1.0f, -1.0f);
        mFrameRecorder.setRenderFlipScale(1.0f, -1.0f);

        if(!TextUtils.isEmpty(mCameraFilterConfig)){
            mFrameRecorder.setFilterWidthConfig(mCameraFilterConfig);
        }
    }

    private int getCameraTimes(int facing) {
        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.FROYO) {
            int numberOfCameras = Camera.getNumberOfCameras();
            Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
            for (int i = 0; i < numberOfCameras; i++) {
                Camera.getCameraInfo(i, cameraInfo);
                if (cameraInfo.facing == facing) {
//                    android.util.Log.e("CM", "createSurfaceTexture orientation:" + cameraInfo.orientation);
                    if (Camera.CameraInfo.CAMERA_FACING_FRONT == facing) {
                        return (360 - cameraInfo.orientation % 360) / 90;
                    } else
                        return 1;
                }
            }
        }
        return 1;
    }

    private void destroySurfaceTexture(){
        android.util.Log.i(LOG_TAG, "destroySurfaceTexture");

        if(mFrameRecorder!=null){
            mFrameRecorder.release();
            mFrameRecorder = null;
            GLES20.glDeleteTextures(1, new int[]{mTextureID}, 0);
            mTextureID = 0;
            mSurfaceTexture.release();
            mSurfaceTexture = null;
            mSurfaceExist=false;
        }
    }

    public interface ReleaseOKCallback {
        void releaseOK();
    }

    public synchronized void release(final ReleaseOKCallback callback) {
        Log.i(LOG_TAG, "GLSurfaceview release 0");
        if(mCameraManager!=null){
            mCameraManager.stopCamera();
            mCameraManager=null;
        }

        if(mFrameRecorder != null) {

            queueEvent(new Runnable() {
                @Override
                public void run() {

                    if (mFrameRecorder != null) {
                        destroySurfaceTexture();

                        Log.i(LOG_TAG, "GLSurfaceview release 1");
                        post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null)
                                    callback.releaseOK();
                            }
                        });
                    }
                }
            });
        }
    }

    private void checkCurrentState() {
        Log.d(LOG_TAG, "call checkCurrentState");
        int targetState;
        int visibiility=getVisibility();

        Log.d(LOG_TAG, "checkCurrentState,mEnabled:" + mEnabled + ", mSurfaceExist:" + mSurfaceExist + ", getVisibility:" + visibiility);
        if (mEnabled && mSurfaceExist && visibiility == View.VISIBLE) {
            targetState = STARTED;
        } else {
            targetState = STOPPED;
        }

        if (targetState != mState) {
            processExitState(mState);
            mState = targetState;
            processEnterState(mState);
        }
    }

    private void processExitState(int state) {
        Log.d(LOG_TAG, "call processExitState: " + state);
        switch(state) {
            case STARTED:
                onExitStartedState();
                break;
            case STOPPED:
                onExitStoppedState();
                break;
            default:
                break;
        }
    }

    private void processEnterState(int state) {
        Log.d(LOG_TAG, "call processEnterState: " + state);
        switch(state) {
            case STARTED:
                onEnterStartedState();
                break;
            case STOPPED:
                onEnterStoppedState();
                break;
            default:
                break;
        }
    }

    private void onEnterStartedState() {
        Log.d(LOG_TAG, "call onEnterStartedState");
        /* Connect camera */
//        if (!startPreview()) {
//            LogUtil.e(TAG,"Device can not open Camera!");
//        }
        requestRender();

        mCameraManager=new CameraManager();
        int facing = mIsCameraBackForward ? Camera.CameraInfo.CAMERA_FACING_BACK : Camera.CameraInfo.CAMERA_FACING_FRONT;
        boolean flag = mCameraManager.tryOpenCamera(new CameraManager.CameraOpenCallback() {
            @Override
            public void cameraReady() {
                mCameraManager.startPreview(mSurfaceTexture);
            }
        },facing);

        if (mCameraListener != null) {
            if (flag)
                mCameraListener.open(0);
            else {
                if (mCameraManager.isCameraOpened())
                    mCameraListener.open(CAMERA_OPENED);
                else
                    mCameraListener.open(CAMERA_OPEN_FAILED);
            }
        }
    }

    private void onExitStartedState() {
//        stopPreview();
        if(mCameraManager!=null){
            mCameraManager.stopCamera();
            mCameraManager=null;
        }
    }

    private void onEnterStoppedState() {
        /* nothing to do */

    }

    private void onExitStoppedState() {
        /* nothing to do */
    }



    /**
     * 当前使用的摄像头
     * @return true：后置摄像头,false:前置摄像头
     */
    public boolean isCameraBackForward() {
        return mIsCameraBackForward;
    }

    private void calcViewport() {

        float scaling;

        if(mIsUsingMask) {
            scaling = mMaskAspectRatio;
        } else {
            scaling = mRecordWidth / (float)mRecordHeight;
        }

        float viewRatio = viewWidth / (float)viewHeight;
        float s = scaling / viewRatio;

        int w, h;

        if(mFitFullView) {
            //撑满全部view(内容大于view)
            if(s > 1.0) {
                w = (int)(viewHeight * scaling);
                h = viewHeight;
            } else {
                w = viewWidth;
                h = (int)(viewWidth / scaling);
            }
        } else {
            //显示全部内容(内容小于view)
            if(s > 1.0) {
                w = viewWidth;
                h = (int)(viewWidth / scaling);
            } else {
                h = viewHeight;
                w = (int)(viewHeight * scaling);
            }
        }

        mDrawViewport.width = w;
        mDrawViewport.height = h;
        mDrawViewport.x = (viewWidth - mDrawViewport.width) / 2;
        mDrawViewport.y = (viewHeight - mDrawViewport.height) / 2;
        Log.i(LOG_TAG, String.format("View port: %d, %d, %d, %d", mDrawViewport.x, mDrawViewport.y, mDrawViewport.width, mDrawViewport.height));
    }

    public void setFitFullView(boolean fit) {
        mFitFullView = fit;
        if(mFrameRecorder != null)
            calcViewport();
    }

    public boolean isUsingMask() {
        return mIsUsingMask;
    }

    public void startCapture(int crop_x,int crop_y,int width, int height, CaptureCallback callback) {
        synchronized (mCaptureLock) {
            this.crop_x=crop_x;
            this.crop_y=crop_y;
            mCaptureCallback = callback;
            mCaptureWidth = width;
            mCaptureHeight = height;
            mCaptureBuffer = ByteBuffer.allocate(width * height*4);
        }
    }

    public void stopCapture() {
        synchronized (mCaptureLock) {
            mCaptureCallback = null;
            mCaptureBuffer = null;
        }
    }

    public void setClearColor(float r, float g, float b, float a) {
        clearColor.r = r;
        clearColor.g = g;
        clearColor.b = b;
        clearColor.a = a;
        queueEvent(new Runnable() {
            @Override
            public void run() {
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
                GLES20.glClearColor(clearColor.r, clearColor.g, clearColor.b, clearColor.a);
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
            }
        });
    }


    //在onSurfaceCreated之前设置有效
    public void presetCameraForward(boolean isBackForward) {
        mIsCameraBackForward = isBackForward;

        setSrcRotation();
    }

    private void setSrcRotation() {
        if (mFrameRecorder == null)
            return;

        final int facing = mIsCameraBackForward ? Camera.CameraInfo.CAMERA_FACING_BACK : Camera.CameraInfo.CAMERA_FACING_FRONT;
        final int times = getCameraTimes(facing);
        mFrameRecorder.setSrcRotation((float) (Math.PI / 2.0 ) * times);
    }

    public void presetCameraFilter(String filterConfig){
        Log.e(LOG_TAG, "presetCameraFilter:"+filterConfig);
        setFilterWithConfig(filterConfig);
    }

    public synchronized void switchCamera() {
        mIsCameraBackForward = !mIsCameraBackForward;
        if(mFrameRecorder != null) {
            queueEvent(new Runnable() {
                @Override
                public void run() {

                    if(mFrameRecorder == null) {
                        Log.e(LOG_TAG, "Error: switchCamera after release!!");
                        return;
                    }

                    if(mCameraManager==null){
                        mCameraManager=new CameraManager();
                    }else{
                        mCameraManager.stopCamera();
                    }


                    int facing = mIsCameraBackForward ? Camera.CameraInfo.CAMERA_FACING_BACK : Camera.CameraInfo.CAMERA_FACING_FRONT;
                    setSrcRotation();
                    mFrameRecorder.setRenderFlipScale(1.0f, -1.0f);

                    if (mIsUsingMask) {
                        mFrameRecorder.setMaskTextureRatio(mMaskAspectRatio);
                    }

                    boolean flag = mCameraManager.tryOpenCamera(new CameraManager.CameraOpenCallback() {
                        @Override
                        public void cameraReady() {
                            if (mCameraManager!=null && !mCameraManager.isPreviewing()) {
                                Log.i(LOG_TAG, "## switch camera -- start preview...");
                                boolean flag = mCameraManager.startPreview(mSurfaceTexture);
                                if (!flag) {
                                    mCameraListener.open(CAMERA_OPEN_FAILED);
                                    return;
                                }
                                mFrameRecorder.srcResize(mCameraManager.previewHeight(), mCameraManager.previewWidth());
                            }
                        }
                    }, facing);

                    if (mCameraListener != null) {
                        if (flag)
                            mCameraListener.open(0);
                        else {
                            if (mCameraManager.isCameraOpened())
                                mCameraListener.open(CAMERA_OPENED);
                            else
                                mCameraListener.open(CAMERA_OPEN_FAILED);
                        }
                    }

                    requestRender();
                }
            });
        }
    }

    //注意， focusAtPoint 会强制 focus mode 为 FOCUS_MODE_AUTO
    //如果有自定义的focus mode， 请在 AutoFocusCallback 里面重设成所需的focus mode。
    //x,y 取值范围: [0, 1]， 一般为 touchEventPosition / viewSize.
    public void focusAtPoint(float x, float y, Camera.AutoFocusCallback focusCallback) {
        mCameraManager.focusAtPoint(y, 1.0f - x, focusCallback);
    }

    // 参数为
    //    Camera.Parameters.FLASH_MODE_AUTO;
    //    Camera.Parameters.FLASH_MODE_OFF;
    //    Camera.Parameters.FLASH_MODE_ON;
    //    Camera.Parameters.FLASH_MODE_RED_EYE
    //    Camera.Parameters.FLASH_MODE_TORCH 等
    public synchronized boolean setFlashLightMode(String mode) {

        if(!getContext().getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) {
            Log.e(LOG_TAG, "does not support flash light!");
            return false;
        }

        if(!mIsCameraBackForward) {
            return false;
        }

        Camera.Parameters parameters = mCameraManager.getParams();

        if(parameters == null)
            return false;

        try {

            if(!parameters.getSupportedFlashModes().contains(mode)) {
                Log.e(LOG_TAG, "Invalid Flash Light Mode!!!");
                return false;
            }

            parameters.setFlashMode(mode);
            mCameraManager.setParams(parameters);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

        return true;
    }

    public synchronized void setFilterWithConfig(String config) {
        mCameraFilterConfig=config;
        queueEvent(new Runnable() {
            @Override
            public void run() {

                if (mFrameRecorder != null) {
                    mFrameRecorder.setFilterWidthConfig(mCameraFilterConfig);
                } else {
                    Log.e(LOG_TAG, "setFilterWithConfig after release!!");
                }
            }
        });
    }

    public void setFilterIntensity(final float intensity) {
        queueEvent(new Runnable() {
            @Override
            public void run() {
                if(mFrameRecorder != null) {
                    mFrameRecorder.setFilterIntensity(intensity);
                } else {
                    Log.e(LOG_TAG, "setFilterIntensity after release!!");
                }
            }
        });
    }

    public interface SetMaskBitmapCallback {
        void setMaskOK(CGEFrameRecorder recorder);
    }

    public interface OpenCameraListener {
        void open(int mode);
    }

    public void setMaskBitmap(final Bitmap bmp, final boolean shouldRecycle) {
        setMaskBitmap(bmp, shouldRecycle, null);
    }

    //注意， 当传入的bmp为null时， SetMaskBitmapCallback 不会执行.
    public void setMaskBitmap(final Bitmap bmp, final boolean shouldRecycle, final SetMaskBitmapCallback callback) {

        queueEvent(new Runnable() {
            @Override
            public void run() {

                if(mFrameRecorder == null) {
                    Log.e(LOG_TAG, "setMaskBitmap after release!!");
                    return;
                }

                if (bmp == null) {
                    mFrameRecorder.setMaskTexture(0, 1.0f);
                    mIsUsingMask = false;
                    calcViewport();
                    return;
                }

                int texID = Common.genNormalTextureID(bmp, GLES20.GL_NEAREST, GLES20.GL_CLAMP_TO_EDGE);

                mFrameRecorder.setMaskTexture(texID, bmp.getWidth() / (float) bmp.getHeight());
                mIsUsingMask = true;
                mMaskAspectRatio = bmp.getWidth() / (float) bmp.getHeight();

                if (callback != null) {
                    callback.setMaskOK(mFrameRecorder);
                }

                if (shouldRecycle)
                    bmp.recycle();

                calcViewport();
            }
        });
    }

}
