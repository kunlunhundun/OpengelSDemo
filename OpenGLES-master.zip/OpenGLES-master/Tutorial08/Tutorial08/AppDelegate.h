//
//  AppDelegate.h
//  Tutorial08
//
//  Created by kesalin@gmail.com kesalin on 12-12-16.
//  Copyright (c) 2012年 http://blog.csdn.net/kesalin/. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
