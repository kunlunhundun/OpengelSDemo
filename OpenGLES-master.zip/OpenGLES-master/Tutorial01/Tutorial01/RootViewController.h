//
//  RootViewController.h
//  Tutorial01
//
//  Created by bux on 2018/2/3.
//

#import <UIKit/UIKit.h>
#import "OpenGLView.h"

@interface RootViewController : UIViewController{

}


@property (strong, retain)  OpenGLView *glView;

@end
